#Memento
"""
Guarda y restaura el estado anterior de un objeto
sin revelar los detalles de su implementación.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from datetime import datetime
from random import sample
from string import ascii_letters, digits


class Original():

    _estado = None

    def __init__(self, estado: str) -> None:
        self._estado = estado
        print(f"En mi estado original no aumento mi ki: {self._estado}")

    def sobrepasar_ki(self) -> None:
        print("Originalmente mi ki es de 100")
        self._estado = self._transformacion()
        print(f"Mi ki aumento porque mi estado cambio: {self._estado}")

    def _transformacion(self, length: int = 10) -> None:
        return "Sayayin"
    def aumento(self) -> Memento:
        return ConcreteMemento(self._estado)

    def disminucion(self, memento: Memento) -> None:
        self._estado = memento.get_estado()
        print(f"Originalmente: mi estado a cambiado a : {self._estado}")


class Memento(ABC):
    @abstractmethod
    def get_name(self) -> str:
        pass
    @abstractmethod
    def get_date(self) -> str:
        pass

class ConcreteMemento(Memento):
    def __init__(self, estado: str) -> None:
        self._estado = estado
        self._date = str(datetime.now())[:19]

    def get_estado(self) -> str:
        return self._estado

    def get_name(self) -> str:
        return f"{self._date} / ({self._estado[0:9]}...)"

    def get_date(self) -> str:
        return self._date


class Cuerpo():
    def __init__(self, original: Original) -> None:
        self._mementos = []
        self._original = original

    def regresar(self) -> None:
        print("\nCuerpo: Guardando estado normal...")
        self._mementos.append(self._original.aumento())

    def hacer(self) -> None:
        if not len(self._mementos):
            return

        memento = self._mementos.pop()
        print(f"Cuerpo: regresandoa su estado: {memento.get_name()}")
        try:
            self._original.disminucion(memento)
        except Exception:
            self.hacer()

    def mostrar_transformaciones(self) -> None:
        print("Cuerpo: Las transformaciones han sido:")
        for memento in self._mementos:
            print(memento.get_name())


if __name__ == "__main__":
    Original = Original("Super-duper-super-puper-super.")
    Cuerpo = Cuerpo(Original)

    Cuerpo.regresar()
    Original.sobrepasar_ki()

    Cuerpo.regresar()
    Original.sobrepasar_ki()

    Cuerpo.regresar()
    Original.sobrepasar_ki()

    print()
    Cuerpo.mostrar_transformaciones()

    print("\nEs hora de regresas!\n")
    Cuerpo.hacer()

    print("\nUna vez mas\n")
    Cuerpo.hacer()
