#Adapter
"""
Adapta a una clase algun metodo con el no cuente. 
Adapta los controles a las consolas de videojuegos.
"""
from abc import ABC,abstractmethod

class Consolas_Videojuego(ABC):
    @abstractmethod
    def Controles(self):
        pass

class Game_Cube(Consolas_Videojuego):
    def Controles(self):
        print("Mi control es de cable con enchufe redondo")

class Playstation(Consolas_Videojuego):
    def Controles(self):
        print("Mis controles son grandes con enchufe redondo")

class Switch:
    def Pantalla_Tactil(self):
        print("Yo puedo jugar con la pantalla de la switch")        
    def Controles_Pantalla(self):
        print("Mis controles estan pagados a la consola")

class IFORU(Consolas_Videojuego):
    def __init__(self):
        self.swit = Switch()
    def Controles(self):
        print("Ahora puedo conectar controles con enchufe redondo a miswitch")
class Jugar:
    def __init__(self):
        self.iforu = IFORU()
        self.P = Playstation()
        self.GC = Game_Cube()
        self.iforu.Controles()
        self.P.Controles()
        self.GC.Controles()
juego = Jugar()
            
