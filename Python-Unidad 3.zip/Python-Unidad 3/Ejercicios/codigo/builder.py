#Builder

"""
Permite construir objetos complejos paso a paso.
"""

import abc

class House(object):

    def __init__(self, type_name):
        self.type = type_name
        self.walls = None
        self.doors = None
        self.windows = None

    def view(self):
        print(
            "This house is a " +
            self.type +
            " with; " +
            str(self.walls) +
            " walls, " +
            str(self.doors) +
            " doors, and " +
            str(self.windows) +
            " windows."
            )

class HouseBuilder(object):
    """
    Una clase de constructor abstracto, para que se deriven constructores
    de concreto.
    """
    __metadata__ = abc.ABCMeta
    
    @abc.abstractmethod
    def make_walls(self):
        raise

    @abc.abstractmethod
    def make_doors(self):
        raise

    @abc.abstractmethod
    def make_windows(self):
        raise

class CabinBuilder(HouseBuilder):

    def __init__(self):
        self.house = House("Cabin ")

    def make_walls(self):
        self.house.walls = 4

    def make_doors(self):
        self.house.doors = 1

    def make_windows(self):
        self.house.windows = 3


class IglooBuilder(HouseBuilder):

    def __init__(self):
        self.house = House("Igloo")

    def make_walls(self):
        self.house.walls = 1

    def make_doors(self):
        self.house.doors = 1

    def make_windows(self):
        self.house.windows = 0

class HouseManufacturer(object):
    """
    La clase de director, mantendrá un constructor concreto.
    """
    
    def __init__(self):
        self.builder = None

    def create(self):
        """ 
        Crea y devuelve una casa usando self.builder
        Precondición: no self.builder es None
        """
        assert not self.builder is None, "No defined builder"
        self.builder.make_walls()
        self.builder.make_doors()
        self.builder.make_windows()
        return self.builder.house

if (__name__ == "__main__"):
    manufacturer = HouseManufacturer()
    
    manufacturer.builder = CabinBuilder()
    cabin = manufacturer.create()
    cabin.view()

    manufacturer.builder = IglooBuilder()
    Igloo = manufacturer.create()
    Igloo.view()
