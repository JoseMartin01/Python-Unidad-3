#Singleton
"""crea una sola instancia de una clase de manera que esta
se pueda acceder de forma global"""

class Codigo_Konami(object):
    def __new__(cls):
        if not hasattr(cls, 'instance'):
            cls.instance = ("Preciona la tecla a,b,z,a,b:")
        return cls.instance

Contra = Codigo_Konami()
Metal_Gear = Codigo_Konami()
Castelvania = Codigo_Konami()
Frigger = Codigo_Konami()

print("Para conseguir tres vidas mas en los juegos Konami preciona \n"+
      "Contra: "+ Contra+
      "\nMetal_Gear: "+ Metal_Gear +
      "\nCastelvania: "+Castelvania+
      "\nFrigger: "+Frigger)
