#Factory
"""
Delega las actividades a clases mas bajas
"""

from abc import ABC, abstractmethod

class Mortal_Kombat(ABC):

    @abstractmethod
    def Base(self):
        pass

    @abstractmethod
    def Mounstruo(self):
         pass

class Tierra(Mortal_Kombat):
        
    def Base(self):
        return JonnyCage()

    def Mounstruo(self):
        return ShaunLao()

class Inframundo(Mortal_Kombat):
    
    def Base(self):
        return SBlade()

    def Mounstruo(self):
        return DVorah()

class Aliado(ABC):
   @abstractmethod
   def Patada(self):
       pass
    
   @abstractmethod
   def Golpe(self):
        pass
    
class Contrario(ABC):
   @abstractmethod
   def Acido(self):
       pass
   @abstractmethod
   def Mordida(self):
        pass

class ShaunLao(Contrario):
    
   def Acido(self):
       print("Derrite la piel")
       
   def Mordida(self):
       print("Arranca la cabeza")
       
class DVorah(Contrario):
    
   def Acido(self):
       print("Quema los ojos")
       
   def Mordida(self):
       print("Muerde el cuello")

class JonnyCage (Aliado):
   def Patada(self):
      print("Patada alta")
   def Golpe(self):
      print("Golpe super potente")

class SBlade (Aliado):
   def Patada(self):
      print("Patada Baja")
   def Golpe(self):
        print("Golpe rompe quijada")

class Torneo:
    def kahon(self):        
        I_factory = Inframundo()
        I_F = I_factory.Mounstruo()
        I_F.Acido()
        I_F.Mordida()
        I_F = I_factory.Base()
        I_F.Patada()
        I_F.Golpe()
        
        T_factory = Tierra()
        T_F = T_factory.Mounstruo()
        T_F.Acido()
        T_F.Mordida()
        T_F = T_factory.Base()
        T_F.Patada()
        T_F.Golpe()   
t = Torneo()
t.kahon()
