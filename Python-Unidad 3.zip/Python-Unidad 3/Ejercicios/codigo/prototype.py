#Prototype
'''
Rermite copiar objetos existentes sin hacer que su código dependa de sus clases.
Ayuda a enteder al usuario cómo un teléfono móvil
puede ser creado ya sea clásico o smarthphone
a partir de un prototipo de teléfono celular.

'''
from abc import ABC, abstractmethod

'''Prototype'''
class PrototypeCellphone(ABC):
    color='Grey'
    brand='Samsung'
    print('Prototype')
    print('Color: ',color)
    print('Brand: ',brand)
    print(' ')
        
    @abstractmethod
    def CloneCellphone(self):
        pass
    
'''ConcretPrototype1'''
class ClassicCellPhone(PrototypeCellphone):
    def __init__(self):
        PrototypeCellphone.__init__(self)
        print('Crear celular clásico')
        
    def CloneCellphone(self):
        
        print('Color: ',PrototypeCellphone.color)
        print('Brand: ',PrototypeCellphone.brand)
    
'''ConcretPrototype2'''
class Smartphone(PrototypeCellphone):
    def __init__(self):
        PrototypeCellphone.__init__(self)
        print('Crear Smartphone')
        
    def CloneCellphone(self):
        
        print('Color: ',PrototypeCellphone.color)
        print('Brand: ',PrototypeCellphone.brand)
class CreateCellphone():
    def __init__(self):
        self.ClassicCellPhone=ClassicCellPhone()
        self.ClassicCellPhone.CloneCellphone()
        self.Smartphone=Smartphone()
        self.Smartphone.CloneCellphone()
create=CreateCellphone()
