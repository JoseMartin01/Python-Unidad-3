#Iterator
"""
es un patrón de diseño de comportamiento que le permite recorrer elementos
de una colección sin exponer su representación subyacente
(lista, pila, árbol, etc.).
recorre los elementos de forma que interactua con ellos pasando de uno por uno.
"""

from __future__ import annotations
from collections.abc import Iterable, Iterator
from typing import Any, List

class Mario_Kart(Iterator):
    _posicion: int = None
    _reversa: bool = False

    def __init__(self, corredor: Corredor, orden: bool = False) -> None:
        self._corredor  = corredor
        self._orden = orden
        self._posicion = -1 if orden else 0

    def __next__(self):
        try:
            valor = self._corredor[self._posicion]
            self._posicion += -1 if self._orden else 1
        except IndexError:
            raise StopIteration()
        return valor

class Corredor(Iterable):
    def __init__(self, personajes: List[Any] = []) -> None:
        self._personajes = personajes
    def __iter__(self) -> Mario_Kart:
        
        return Mario_Kart(self._personajes)

    def recorrer_corredores(self) -> Mario_Kart:
        return Mario_Kart(self._personajes, True)

    def agregar_carro(self, item: Any):
        self._personajes.append(item)
if __name__ == "__main__":
    mtg  = Corredor()
    mtg.agregar_carro("Mario")
    mtg.agregar_carro("Luigi")
    mtg.agregar_carro("Peach")
    mtg.agregar_carro("Bowser")
    mtg.agregar_carro("Toad")
    mtg.agregar_carro("DK")

    print("Lista de todos los presonajes de mejor a peor:")
    print("\n".join(mtg))
    print("")

    print("Lista de todos los presonajes de peor a mejor")
    print("\n".join(mtg.recorrer_corredores()), end="")

    
